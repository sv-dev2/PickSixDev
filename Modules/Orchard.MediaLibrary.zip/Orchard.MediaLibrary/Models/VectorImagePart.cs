﻿using Orchard.ContentManagement;

namespace Orchard.MediaLibrary.Models {
    public class VectorImagePart : ContentPart {
    }
}